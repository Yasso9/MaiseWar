package main.framework.entities;


public class Character {

    // attributes
    double physicalAttribute;
    double mentalAttribute;

    // stats
    double prowess;
    double endurance;


}
